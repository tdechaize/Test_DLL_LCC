//*********************    File : testdll.h (include file test of dll)    *****************
#ifndef HEADER_TESTDLL
#define HEADER_TESTDLL

extern int hello(void);
extern int add (int i1, int i2);
extern int substract (int i1, int i2);
extern int multiply (int i1, int i2);

#endif // header guard
//******************************    End file : testdll.h   *********************************
