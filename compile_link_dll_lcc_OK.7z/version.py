import sys,platform
print("Version python : ",sys.version_info[0],".",sys.version_info[1]," ",platform.architecture()[0],sep='')